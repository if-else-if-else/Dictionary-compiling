﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dictionary_compiling
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            { 
                Console.Title = "Составление словаря";
                Console.WriteLine("Составление числового словаря от 0 до n");
                Console.Write("Введите конечное значение: ");
                int Number = Convert.ToInt32(Console.ReadLine());
    
                using (StreamWriter writer = new StreamWriter("Numbers.txt"))
                {
                    for (int i = 0; i <= Number; i++)
                    {
                        writer.WriteLine(i);
                    }
                }
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Готово!");
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("Файл создан в папке с исполняемым файлом.");
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("Ошибка при создании файла: ");
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
    }
}
